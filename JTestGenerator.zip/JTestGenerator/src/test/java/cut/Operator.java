package cut;

public class Operator {
}
