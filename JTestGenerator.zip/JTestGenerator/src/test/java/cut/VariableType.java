package cut;

public class VariableType {
    enum EnumExample {
        SGT, PEPPER, S, LONELY, HEARTS, CLUB, BAND
    }
    public void multiType(int[] a, boolean b, char c, double d, byte e, float f, int i, short s, long l, EnumExample h) {
        if(a.length==1){
            return;
        }

        return;
    }
}
