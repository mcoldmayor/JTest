package cut;

public class LogicStructure {

    public int sequence(int a, int b) {
        return a + b;
    }

    public boolean soloIf(int op) {
        if (op > 0)
            return true;
        return false;
    }

    public boolean ifElse(int op) {
        op=op+1;
        op=op*2;
        if (op > 18)
            return true;
        else
            return false;
    }

    public String multipleIf(int op) {
        if (op % 15 == 0)
            return "FizzBuzz";
        else if (op % 5 == 0)
            return "Buzz";
        else if (op % 3 == 0)
            return "Fizz";
        else
            return Integer.toString(op);
    }

    public int loopWhile(int a, int b) {
        while (a < 15) {
            b += a;
            a ++;
        }
        return b;
    }

    public int complexLoop(int i, int j) {
        while(i<j && i<0) {

            if(i < 0) {
                i = i+1;
            } else {
                j = j-2;
            }
            if(i == 0) {
                return i;
            }
        }
        return j;
    }
}
