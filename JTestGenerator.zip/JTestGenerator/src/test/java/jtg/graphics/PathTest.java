package jtg.graphics;

import org.junit.jupiter.api.Test;
import soot.Unit;
import soot.toolkits.graph.UnitGraph;

import java.io.File;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class PathTest {

    @Test
    void solo_if_prime() {
        String clspath = System.getProperty("user.dir") + File.separator + "target" + File.separator + "test-classes";
        String clsName = "cut.LogicStructure";
        String methodName = "soloIf";
        UnitGraph ug = SootCFG.getMethodCFG(clspath,clsName, methodName);
        List<List<Unit>> r = Findpath.getAllPrimePath(ug);
        System.out.println(r);
        assertTrue(r.size() == 2);
    }

    @Test
    void if_else_prime() {
        String clspath = System.getProperty("user.dir") + File.separator + "target" + File.separator + "test-classes";
        String clsName = "cut.LogicStructure";
        String methodName = "ifElse";
        UnitGraph ug = SootCFG.getMethodCFG(clspath,clsName, methodName);
        List<List<Unit>> r = Findpath.getAllPrimePath(ug);
        System.out.println(r);
        assertTrue(r.size() == 2);


    }

    @Test
    void multiple_if_prime() {
        String clspath = System.getProperty("user.dir") + File.separator + "target" + File.separator + "test-classes";
        String clsName = "cut.LogicStructure";
        String methodName = "multipleIf";
        UnitGraph ug = SootCFG.getMethodCFG(clspath,clsName, methodName);
        List<List<Unit>> r = Findpath.getAllPrimePath(ug);
        System.out.println(r);
        assertTrue(r.size() == 4);

    }
    @Test
    void sequence_prime() {
        String clspath = System.getProperty("user.dir") + File.separator + "target" + File.separator + "test-classes";
        String clsName = "cut.LogicStructure";
        String methodName = "sequence";
        UnitGraph ug = SootCFG.getMethodCFG(clspath, clsName, methodName);
        List<List<Unit>> r = Findpath.getAllPrimePath(ug);
        System.out.println(r);
        assertTrue(r.size() == 1);
    }

    @Test
    void while_loop_prime() {
        String clspath = System.getProperty("user.dir") + File.separator + "target" + File.separator + "test-classes";
        String clsName = "cut.LogicStructure";
        String methodName = "loopWhile";
        UnitGraph ug = SootCFG.getMethodCFG(clspath, clsName, methodName);
        List<List<Unit>> r = Findpath.getAllPrimePath(ug);
        System.out.println(r);
        assertTrue(r.size() == 7);
    }
}
