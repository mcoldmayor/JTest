package jtg.generator;

import org.junit.jupiter.api.Test;

import java.io.File;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class PrimePathCoverageGeneratorTest {
    @Test
    void solo_if_correct() {
        String clspath = System.getProperty("user.dir") + File.separator + "target" + File.separator + "test-classes";
        String clsName = "cut.LogicStructure";
        String methodName = "soloIf";
        PrimePathCoverageGenerator sg = new PrimePathCoverageGenerator(clspath, clsName, methodName);
        List<String> ts = sg.generate();
        assertTrue(!ts.isEmpty());
    }

    @Test
    void if_else_correct() {
        String clspath = System.getProperty("user.dir") + File.separator + "target" + File.separator + "test-classes";
        String clsName = "cut.LogicStructure";
        String methodName = "ifElse";
        PrimePathCoverageGenerator sg = new PrimePathCoverageGenerator(clspath, clsName, methodName);
        List<String> ts = sg.generate();
        assertTrue(!ts.isEmpty());


    }

    @Test
    void multiple_if_correct() {
        String clspath = System.getProperty("user.dir") + File.separator + "target" + File.separator + "test-classes";
        String clsName = "cut.LogicStructure";
        String methodName = "multipleIf";
        PrimePathCoverageGenerator sg = new PrimePathCoverageGenerator(clspath, clsName, methodName);
        List<String> ts = sg.generate();
        assertTrue(!ts.isEmpty());

    }

    @Test
    void loop_while_correct() {
        String clspath = System.getProperty("user.dir") + File.separator + "target" + File.separator + "test-classes";
        String clsName = "cut.LogicStructure";
        String methodName = "loopWhile";
        PrimePathCoverageGenerator sg = new PrimePathCoverageGenerator(clspath, clsName, methodName);
        List<String> ts = sg.generate();
        assertTrue(!ts.isEmpty());

    }

    @Test
    void loop_while_complex() {
        String clspath = System.getProperty("user.dir") + File.separator + "target" + File.separator + "test-classes";
        String clsName = "cut.LogicStructure";
        String methodName = "complexLoop";
        PrimePathCoverageGenerator sg = new PrimePathCoverageGenerator(clspath, clsName, methodName);
        List<String> ts = sg.generate();
        assertTrue(!ts.isEmpty());
    }

    @Test
    void variable_type_correct() {
        String clspath = System.getProperty("user.dir") + File.separator + "target" + File.separator + "test-classes";
        String clsName = "cut.VariableType";
        String methodName = "multiType";
        PrimePathCoverageGenerator sg = new PrimePathCoverageGenerator(clspath, clsName, methodName);
        List<String> ts = sg.generate();
        System.out.println("Generated Test Cases: " + ts);
        assertTrue(!ts.isEmpty());

    }

    @Test
    void sequence_correct() {
        String clspath = System.getProperty("user.dir") + File.separator + "target" + File.separator + "test-classes";
        String clsName = "cut.LogicStructure";
        String methodName = "sequence";
        PrimePathCoverageGenerator sg = new PrimePathCoverageGenerator(clspath, clsName, methodName);
        List<String> ts = sg.generate();
        assertTrue(!ts.isEmpty());

    }

}
