package jtg.generator;

import org.junit.jupiter.api.Test;

import java.io.File;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class DataFlowTest {
    @Test
    void solo_if_correct() {
        String clspath = System.getProperty("user.dir") + File.separator + "target" + File.separator + "test-classes";
        String clsName = "cut.LogicStructure";
        String methodName = "soloIf";
        DataFlowGenerator dg = new DataFlowGenerator(clspath, clsName, methodName);
        List<String> ts = dg.generate(DataFlowGenerator.FLOW_ALL_DEF);
        assertTrue(!ts.isEmpty());
    }

    @Test
    void if_else_correct() {
        String clspath = System.getProperty("user.dir") + File.separator + "target" + File.separator + "test-classes";
        String clsName = "cut.LogicStructure";
        String methodName = "ifElse";
        DataFlowGenerator dg = new DataFlowGenerator(clspath, clsName, methodName);
        List<String> ts = dg.generate(DataFlowGenerator.FLOW_ALL_DEF);
        assertTrue(!ts.isEmpty());


    }

    @Test
    void multiple_if_correct() {
        String clspath = System.getProperty("user.dir") + File.separator + "target" + File.separator + "test-classes";
        String clsName = "cut.LogicStructure";
        String methodName = "multipleIf";
        DataFlowGenerator dg = new DataFlowGenerator(clspath, clsName, methodName);
        List<String> ts = dg.generate(DataFlowGenerator.FLOW_ALL_DEF);
        assertTrue(!ts.isEmpty());

    }

    @Test
    void loop_while_correct() {
        String clspath = System.getProperty("user.dir") + File.separator + "target" + File.separator + "test-classes";
        String clsName = "cut.LogicStructure";
        String methodName = "loopWhile";
        DataFlowGenerator dg = new DataFlowGenerator(clspath, clsName, methodName);
        List<String> ts = dg.generate(DataFlowGenerator.FLOW_ALL_DEF);
        assertTrue(!ts.isEmpty());

    }

    @Test
    void multiple_if_all_use() {
        String clspath = System.getProperty("user.dir") + File.separator + "target" + File.separator + "test-classes";
        String clsName = "cut.LogicStructure";
        String methodName = "multipleIf";
        DataFlowGenerator dg = new DataFlowGenerator(clspath, clsName, methodName);
        List<String> ts = dg.generate(DataFlowGenerator.FLOW_ALL_USE);
        assertTrue(!ts.isEmpty());

    }

    @Test
    void loop_while_all_defuse() {
        String clspath = System.getProperty("user.dir") + File.separator + "target" + File.separator + "test-classes";
        String clsName = "cut.LogicStructure";
        String methodName = "loopWhile";
        DataFlowGenerator dg = new DataFlowGenerator(clspath, clsName, methodName);
        List<String> ts = dg.generate(DataFlowGenerator.FLOW_ALL_DEF_USE);
        assertTrue(!ts.isEmpty());

    }
}
