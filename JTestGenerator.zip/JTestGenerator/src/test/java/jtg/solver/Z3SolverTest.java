package jtg.solver;

import org.junit.jupiter.api.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

class Z3SolverTest {

    @Test
    void sat_two_ints_add() throws Exception{
        String result = Z3Solver.solve("a + b = 10");
        System.out.println(result);
        assertThat(result,containsString("a="));
        assertThat(result,containsString("b="));
    }

    @Test
    void sat_multi_stmt() throws Exception{
        String result = Z3Solver.solve("((i0+2)*2)>18");
        System.out.println(result);
        assertThat(result,containsString("i0="));
    }

}