package jtg.exception;

public class ConstraintSolveException extends Exception {
    public ConstraintSolveException(String message) {
        super(message);
    }
}
