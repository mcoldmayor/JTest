package jtg.visualizer;

public class TGConsole {
    public static PrintTarget out = new StdoutTarget();

}
