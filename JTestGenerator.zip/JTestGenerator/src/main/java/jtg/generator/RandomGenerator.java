package jtg.generator;

import jtg.graphics.SootCFG;
import jtg.visualizer.Visualizer;
import soot.Body;
import soot.Local;
import soot.toolkits.graph.UnitGraph;

import java.io.File;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class RandomGenerator {

    private String clsPath;
    private String clsName;
    private String mtdName;
    private UnitGraph ug;
    private Body body;


    public RandomGenerator(String className, String methodName) {
        String defaultClsPath = System.getProperty("user.dir") + File.separator + "target" + File.separator + "classes";
        new RandomGenerator(defaultClsPath, className, methodName);
    }

    public RandomGenerator(String classPath, String className, String methodName) {
        clsPath = classPath;
        clsName = className;
        mtdName = methodName;
        ug = SootCFG.getMethodCFG(clsPath, clsName, mtdName);
        body = SootCFG.getMethodBody(clsPath, clsName, mtdName);
    }

    public void drawCFG(String graphName, boolean indexLabel) {
        Visualizer.printCFGDot(graphName, ug, indexLabel);
    }


    private List<Local> getJVars() {
        //Jimple自身增加的Locals，不是被测代码真正的变量
        ArrayList<Local> jimpleVars = new ArrayList<Local>();
        for (Local l : body.getLocals()) {
            if (l.toString().startsWith("$")) jimpleVars.add(l);
        }
        return jimpleVars;
    }

    /**
     * Randomly generate random count test cases for the method
     * @return list of test cases
     */
    public List<String> generate() {
        return generate(1+(int)Math.random()*15);
    }

    /**
     * Randomly generate tcCount test cases for the method
     * @param tcCount the count of test cases
     * @return list of test cases
     */
    public List<String> generate(int tcCount) {

        ArrayList<String> testSet = null;

        System.out.println("==================================================================================");
        System.out.println("Randomly generating test case inputs for method: " + clsName + "." + mtdName + "()");
        System.out.println("==================================================================================");


        try {
            testSet = new ArrayList<String>();
            for (int i = 0; i < tcCount; i++) {
                    testSet.add(randomTC(body.getParameterLocals()));
            }
        } catch (Exception e) {
            System.err.println("Error in generating test cases: ");
            System.err.println(e.toString());
        }
        if (!testSet.isEmpty()) {
            System.out.println("");
            System.out.println("The generated test case inputs:");
            int count = 1;
            for (String tc : testSet) {
                System.out.println("( " + count + " ) " + tc.toString());
                count++;
            }
        }
        return testSet;
    }



    public String randomTC(List<Local> parameters) {

        String varName;
        String varValue = "";
        String testinput = "";


        for (Local para : parameters) {
            varName = para.getName();
            String type = para.getType().toString();
            varValue = findTypeValue(type);
            testinput = testinput + " " + varName + "=" + varValue;
        }
        return testinput;
    }

    public static String findTypeValue(String type) {
        Random random = new Random();

        if (type.contains("[]")) {  //如果 type 包含 "[]"则认为它是数组类型。
            int l = random.nextInt(16);//在这种情况下，代码生成一个包含随机元素的数组，数组的长度在 0 到 15 之间随机确定。
            String oriType = type.substring(0, type.indexOf("[]"));
            StringBuilder sb = new StringBuilder("[");
            for (int i = 0; i < l; i++) {
                sb.append(findTypeValue(oriType));//数组元素的类型由 oriType 决定，通过递归调用 findTypeValue(oriType) 来生成数组中每个元素的值。
                sb.append(i==l-1?"]":", ");
            }
            if(l==0){
                sb.append("]");
            }
            return sb.toString();
        }
        else if ("int".equals(type)) {//如果 type 是 "int"，则生成一个随机整数，乘以随机布尔值来确定正负。
            return String.valueOf(random.nextInt() * (random.nextBoolean()?1:-1));
        } else if ("String".equals(type)||"java.lang.String".equals(type)) {
            return randomStr(random.nextInt(256));//如果 type 是 "String" 或者 "java.lang.String"，则生成一个随机字符串，长度在 0 到 255 之间。
        } else if ("boolean".equals(type)){//如果 type 是 "boolean"，则生成一个随机布尔值。
            return String.valueOf(random.nextBoolean());
        } else if ("short".equals(type)) {//如果 type 是 "short"，则生成一个随机 short 整数，乘以随机布尔值来确定正负。
            return String.valueOf(random.nextInt(Short.MAX_VALUE) * (random.nextBoolean()?-1:1));
        } else if ("long".equals(type)) {//如果 type 是 "long"，则生成一个随机 long 整数。
            return String.valueOf(random.nextLong());
        } else if ("byte".equals(type)) {//如果 type 是 "byte"，则生成一个随机 byte 整数，乘以随机布尔值来确定正负。
            return String.valueOf(random.nextInt(Byte.MAX_VALUE) * (random.nextBoolean()?-1:1));
        } else if ("char".equals(type)) {//如果 type 是 "char"，则生成一个长度为 1 的随机字符串。
            return randomStr(1);
        } else if ("float".equals(type)) {//如果 type 是 "float"，则生成一个随机 float 数。
            return String.valueOf(random.nextFloat());
        } else if ("double".equals(type)) {//如果 type 是 "double"，则生成一个随机 double 数。
            return String.valueOf(random.nextDouble());
        } else {//当 type 既不是基本数据类型，也不是字符串、数组等已知类型时的情况
            try {
                Class c = Class.forName(type);
                if (c.isEnum()) {//判断该类是否为枚举类型，如果是，则随机选择该枚举类型的一个常量，并返回其字符串表示。
                    return c.getEnumConstants()[random.nextInt(c.getEnumConstants().length)].toString();
                }
                Field[] fs = c.getFields();//如果不是枚举类型，获取该类的所有字段 Field[] fs。
                StringBuilder sb = new StringBuilder();
                for(Field f:fs) {
                    if (sb.length() == 0) {
                        sb.append('{');
                    } else {
                        sb.append(", ");
                    }
                    sb.append(f.getName()+"="+ findTypeValue(f.getType().getName()));
                }
                sb.append('}');
                return sb.toString();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
        return " ";
    }


    public static String randomStr(int len) {
        StringBuilder str = new StringBuilder();
        char[] randchar = "1324567890~!@#$%^&*()_+`-=[]{}\\|;:\'\"/?.>,<qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM".toCharArray();
        Random random = new Random();
        for (int i = 0; i < len; i++) {
            str.append(randchar[random.nextInt(randchar.length)]);
        }
        return str.toString();
    }
}
