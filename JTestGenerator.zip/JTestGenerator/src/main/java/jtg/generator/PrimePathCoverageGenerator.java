package jtg.generator;

import jtg.graphics.Findpath;
import jtg.graphics.SootCFG;
import jtg.solver.Z3Solver;
import jtg.utils.Tuple;
import jtg.visualizer.Visualizer;
import soot.Body;
import soot.Local;
import soot.Unit;
import soot.jimple.internal.JAssignStmt;
import soot.jimple.internal.JIfStmt;
import soot.jimple.internal.JReturnStmt;
import soot.toolkits.graph.UnitGraph;

import java.io.File;
import java.util.*;

public class PrimePathCoverageGenerator {

    private String clsPath;
    private String clsName;
    private String mtdName;
    private UnitGraph ug;
    private Body body;


    public PrimePathCoverageGenerator(String className, String methodName) {
        String defaultClsPath = System.getProperty("user.dir") + File.separator + "target" + File.separator + "classes";
        new SimpleGenerator(defaultClsPath, className, methodName);
    }

    public PrimePathCoverageGenerator(String classPath, String className, String methodName) {
        clsPath = classPath;
        clsName = className;
        mtdName = methodName;
        ug = SootCFG.getMethodCFG(clsPath, clsName, mtdName);
        body = SootCFG.getMethodBody(clsPath, clsName, mtdName);
    }

    private List<Local> getJVars() {
        //Jimple自身增加的Locals，不是被测代码真正的变量
        ArrayList<Local> jimpleVars = new ArrayList<Local>();
        for (Local l : body.getLocals()) {
            if (l.toString().startsWith("$")) {
                jimpleVars.add(l);
            }
        }
        return jimpleVars;
    }

    private List<Local> getParameter() {
        ArrayList<Local> paras = new ArrayList<Local>();
        for (Local para : body.getParameterLocals()) {
            paras.add(para);
        }
        return paras;
    }

    public List<String> generate() {

        List<Unit> path = null;
        ArrayList<String> testSet = null;
        String pathConstraint = "";
        int primePathCount = 0;
        int primePathCoveredCount = 0;
        List<List<Unit>> impossiblePrimePaths = new ArrayList<>();

        System.out.println("============================================================================");
        System.out.println("Generating test case inputs for method: " + clsName + "." + mtdName + "()");
        System.out.println("============================================================================");

        try {
            testSet = new ArrayList<String>();

            List<List<Unit>> primePaths = Findpath.getAllPrimePath(ug);
            primePathCount = primePaths.size();

            for (List<Unit> primePath : primePaths) {
                List<List<Unit>> headToHerePaths;
                List<List<Unit>> hereToTailPaths;
                headToHerePaths = Findpath.getAllSimplePathBetween(ug.getHeads(),
                        primePath.get(0), ug);
                hereToTailPaths = Findpath.getAllSimplePathBetween(primePath.get(primePath.size() - 1),
                        ug.getTails(), ug);
                List<Unit> tempPath = new ArrayList<>();
                boolean isPossible = false;
                Tuple tempTuple = new Tuple<String, String>("", "");

                findPath:
                for (List<Unit> headToHerePath : headToHerePaths) {
                    for (List<Unit> hereToTailPath : hereToTailPaths) {
                        tempPath = primePath;
                        tempPath.addAll(0, headToHerePath.subList(0,headToHerePath.size()-1));
                        tempPath.addAll(hereToTailPath.subList(1,hereToTailPath.size()));

                        tempTuple = calPathConstraintWithoutPrint(tempPath);
                        pathConstraint = (String) tempTuple.second;

                        if (!pathConstraint.isEmpty() && solve(pathConstraint).equals("")) {
                        } else {
                            if (pathConstraint.isEmpty()) {
                                String curTestCase=randomTC(body.getParameterLocals());
                                if(!testSet.contains(curTestCase)){
                                    testSet.add(curTestCase);
                                }

                            } else {
                                String curTestCase=solve(pathConstraint);
                                if(!testSet.contains(curTestCase)){
                                    testSet.add(curTestCase);
                                }
                            }
                            primePathCoveredCount++;
                            isPossible = true;
                            break findPath;

                        }

                    }
                }
                if (isPossible) {
                    System.out.println("The path is: " + tempPath.toString());
                    System.out.println("The covered prime path is: "+primePath);
                    System.out.println(tempTuple.first);
                    System.out.println("The corresponding path constraint is: " + pathConstraint);
                    System.out.println("----------------------------------------------------------------------------");
                } else {
                    impossiblePrimePaths.add(primePath);
                }

            }

        } catch (Exception e) {
            System.err.println("Error in generating test cases: ");
            System.err.println(e.toString());
        }

        if (!testSet.isEmpty()) {
            System.out.println("");
            System.out.println("The generated test case inputs:");
            int count = 1;

            for (String tc : testSet) {
                System.out.println("( " + count + " ) " + tc.toString());
                count++;
            }
        }

        System.out.println("The coverage rate is " + primePathCoveredCount + " / " + primePathCount + " .");
        if (!impossiblePrimePaths.isEmpty()) {
            System.out.println("The impossible prime path are:");

            for (List<Unit> impossiblePrimePath : impossiblePrimePaths) {
                System.out.println("The path is: " + impossiblePrimePath);
            }
        }

        return testSet;
    }

    public Tuple<String, String> calPathConstraintWithoutPrint(List<Unit> path) {

        List<Local> jVars = getJVars();

        String pathConstraint = "";
        String expectedResult = "";

        HashMap<String, String> assignList = new HashMap<>();
        ArrayList<String> stepConditionsWithJimpleVars = new ArrayList<String>();
        ArrayList<String> stepConditions = new ArrayList<String>();

        String stringToPrint = "";


        for (int i=0;i<path.size();i++) {
            Unit stmt=path.get(i);

            if (stmt instanceof JAssignStmt) {
                assignList.put(((JAssignStmt) stmt).getLeftOp().toString(),
                        ((JAssignStmt) stmt).getRightOp().toString());
                continue;
            }
            if (stmt instanceof JIfStmt) {

                String ifstms = ((JIfStmt) stmt).getCondition().toString();
                int nextUnitIndex = path.indexOf(stmt) + 1;
                Unit nextUnit = path.get(nextUnitIndex);

                //如果ifstmt的后继语句不是ifstmt中goto语句，说明ifstmt中的条件为假
                if (!((JIfStmt) stmt).getTarget().equals(nextUnit)) {
                    ifstms = "!( " + ifstms + " )";
                } else {
                    ifstms = "( " + ifstms + " )";
                }

                for(int j=i;j>=0;j--){
                    Unit assignHistory=path.get(j);
                    if (assignHistory instanceof JAssignStmt) {

                        ifstms=ifstms.replaceAll(" "+((JAssignStmt) assignHistory).getLeftOp().toString()+" ",
                                "( " + ((JAssignStmt) assignHistory).getRightOp().toString()+" )");

                        continue;
                    }
                }

                stepConditionsWithJimpleVars.add(ifstms);
                continue;
            }
            if (stmt instanceof JReturnStmt) {
                expectedResult = stmt.toString().replace("return", "").trim();
            }
        }


        stringToPrint = "The step conditions with JimpleVars are: " + stepConditionsWithJimpleVars;

        if (jVars.size() != 0) {
            for (String cond : stepConditionsWithJimpleVars) {
                //替换条件里的Jimple变量
                for (Local lv : jVars) {
                    if (cond.contains(lv.toString())) {
                        stepConditions.add(cond.replace(lv.toString(), assignList.get(lv.toString()).trim()));
                    }
                }
            }
        } else {
            stepConditions = stepConditionsWithJimpleVars;
        }

        if (stepConditions.isEmpty()) {
            return new Tuple<>(stringToPrint, "");
        }
        pathConstraint = stepConditions.get(0);
        int i = 1;
        while (i < stepConditions.size()) {
            pathConstraint = pathConstraint + " && " + stepConditions.get(i);
            i++;
        }
//        for(String left:assignList.keySet()){
//            pathConstraint =pathConstraint + " && " + left +" = " + assignList.get(left);
//        }

        //System.out.println("The path expression is: " + pathConstraint);
        return new Tuple<>(stringToPrint, pathConstraint);
    }

    public String solve(String pathConstraint) throws Exception {
        return Z3Solver.solve(pathConstraint);
    }

    public String randomTC(List<Local> parameters) {

        String varName;
        String varValue = "";
        String testinput = "";


        for (Local para : parameters) {
            varName = para.getName();
            String type = para.getType().toString();
            varValue = getRandomOfType(type);

            testinput = testinput + " " + varName + "=" + varValue;
        }
        return testinput;
    }

    public static String getRandomOfType(String type) {
        Random random = new Random();

        if (type.indexOf("[]") != -1) {
            int l = random.nextInt(16);
            String oriType = type.substring(0, type.indexOf("[]"));
            StringBuilder sb = new StringBuilder("[");
            for (int i = 0; i < l; i++) {
                sb.append(getRandomOfType(oriType));
                sb.append(i==l-1?"]":", ");
            }
            if(l==0){
                sb.append("]");
            }
            return sb.toString();
        } else if ("int".equals(type)) {
            return String.valueOf(random.nextInt() * (random.nextBoolean()?1:-1));
        } else if ("String".equals(type)) {
            return randomStr(random.nextInt(256));
        } else if ("boolean".equals(type)){
            return String.valueOf(random.nextBoolean());
        } else if ("short".equals(type)) {
            return String.valueOf(random.nextInt(Short.MAX_VALUE) * (random.nextBoolean()?-1:1));
        } else if ("long".equals(type)) {
            return String.valueOf(random.nextLong());
        } else if ("byte".equals(type)) {
            return String.valueOf(random.nextInt(Byte.MAX_VALUE) * (random.nextBoolean()?-1:1));
        } else if ("char".equals(type)) {
            return randomStr(1);
        } else if ("float".equals(type)) {
            return String.valueOf(random.nextFloat());
        } else if ("double".equals(type)) {
            return String.valueOf(random.nextDouble());
        } else {
            try {
                Class c = Class.forName(type);
                if (c.isEnum()) {
                    return c.getEnumConstants()[random.nextInt(c.getEnumConstants().length)].toString();
                }
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
        return " ";
    }


    public static String randomStr(int len) {
        StringBuilder str = new StringBuilder();
        char[] randchar = "1324567890~!@#$%^&*()_+`-=[]{}\\|;:\'\"/?.>,<qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM".toCharArray();
        Random random = new Random();
        for (int i = 0; i < len; i++) {
            str.append(randchar[random.nextInt(randchar.length)]);
        }
        return str.toString();
    }

    public void drawCFG(String graphName, boolean indexLabel) {
        Visualizer.printCFGDot(graphName, ug, indexLabel);
    }
}
