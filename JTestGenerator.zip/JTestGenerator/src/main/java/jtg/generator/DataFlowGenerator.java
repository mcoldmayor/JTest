package jtg.generator;

import jtg.graphics.Findpath;
import jtg.graphics.SootCFG;
import jtg.solver.Z3Solver;
import jtg.utils.Tuple;
import soot.Body;
import soot.Local;
import soot.Unit;
import soot.ValueBox;
import soot.jimple.internal.JAssignStmt;
import soot.jimple.internal.JIfStmt;
import soot.jimple.internal.JReturnStmt;
import soot.toolkits.graph.UnitGraph;

import java.io.File;
import java.util.*;

public class DataFlowGenerator {
    final public static int FLOW_ALL_DEF = 0;
    final public static int FLOW_ALL_USE = 1;
    final public static int FLOW_ALL_DEF_USE = 2;

    private String clsPath;
    private String clsName;
    private String mtdName;
    private UnitGraph ug;
    private Body body;

    private HashMap<String, Set<Unit>> defMapping = new HashMap<>();
    private HashMap<String, Set<Unit>> useMapping = new HashMap<>();
    private HashMap<String, Set<Tuple<Unit, Unit>>> duPairs = new HashMap<>();

    private int defCount;
    private int useCount;


    public DataFlowGenerator(String className, String methodName) {
        String defaultClsPath = System.getProperty("user.dir") + File.separator + "target" + File.separator + "classes";
        new SimpleGenerator(defaultClsPath, className, methodName);
    }

    public DataFlowGenerator(String classPath, String className, String methodName) {
        clsPath = classPath;
        clsName = className;
        mtdName = methodName;
        ug = SootCFG.getMethodCFG(clsPath, clsName, mtdName);
        body = SootCFG.getMethodBody(clsPath, clsName, mtdName);

        initMap();
    }

    private List<Local> getJVars() {
        //Jimple自身增加的Locals，不是被测代码真正的变量
        ArrayList<Local> jimpleVars = new ArrayList<Local>();
        for (Local l : body.getLocals()) {
            if (l.toString().startsWith("$")) {
                jimpleVars.add(l);
            }
        }
        return jimpleVars;
    }

    private List<Local> getParameter() {
        ArrayList<Local> paras = new ArrayList<Local>();
        for (Local para : body.getParameterLocals()) {
            paras.add(para);
        }
        return paras;
    }

    public void initMap() {
        Iterator<Unit> it = ug.iterator();
        while(it.hasNext()) {
            Unit u = it.next();
            List<ValueBox> defb = u.getDefBoxes();
            List<ValueBox> useb = u.getUseBoxes();
            // def mapping
            for(ValueBox vb:defb) {
                String key = vb.getValue().toString();
                if(!defMapping.containsKey(key)) {
                    defMapping.put(key, new HashSet<>());
                }
                defMapping.get(key).add(u);
            }
            // use mapping
            for(ValueBox vb:useb) {
                String key = vb.getValue().toString();
                if(!useMapping.containsKey(key)) {
                    useMapping.put(key, new HashSet<>());
                }
                useMapping.get(key).add(u);
            }
        }

        for (Local l:body.getLocals()) {
            String name = l.getName();
            if (!defMapping.containsKey(name) || !useMapping.containsKey(name)) {
                continue;
            }
            Set<Unit> def = defMapping.get(name);
            Set<Unit> use = useMapping.get(name);
            if(!duPairs.containsKey(name)) {
                duPairs.put(name, new HashSet<>());
            }
            for(Unit d:def) {
                for(Unit u:use) {
                    duPairs.get(name).add(new Tuple<>(d, u));
                }
            }

        }

    }

    public List<List<Unit>> getAllDefPaths() {
        HashSet<Unit> defed = new HashSet<>();
        List<List<Unit>> result = new ArrayList<>();
        List<List<Unit>> now;
        for(String name:duPairs.keySet()) {
            for(Tuple<Unit, Unit> pair:duPairs.get(name)) {
                if (defed.contains(pair.first)) {
                    continue;
                }
                now = getDUPath(pair);
                if (now.size()>0) {
                    result.add(now.get(0));
                    defed.add(pair.first);
                }

            }
            defed.clear();
        }
        return result;
    }

    public List<List<Unit>> getAllUsePaths() {
        HashSet<Unit> useed = new HashSet<>();
        List<List<Unit>> result = new ArrayList<>();
        List<List<Unit>> now;
        for(String name:duPairs.keySet()) {
            for(Tuple pair:duPairs.get(name)) {
                now = getDUPath(pair);
                if (now.size()!=0) {
                    result.add(now.get(0));
                }

            }
            useed.clear();
        }
        return result;
    }

    public List<List<Unit>> getAllDUPaths() {
        List<List<Unit>> result = new ArrayList<>();
        List<List<Unit>> now;
        for(String name:duPairs.keySet()) {
            for(Tuple pair:duPairs.get(name)) {
                now = getDUPath(pair);
                result.addAll(now);
            }
        }
        return result;
    }

    public List<List<Unit>> getDUPath(Tuple<Unit, Unit> pair) {
        return Findpath.getAllSimplePathBetween(pair.first, pair.second, this.ug);
    }

    public List<String> generate(int type) {
        List<List<Unit>> innerPaths;
        List<Unit> path = null;
        ArrayList<String> testSet = null;
        String pathConstraint = "";
        int pathCount = 0;
        int pathCoveredCount = 0;
        List<List<Unit>> impossiblePrimePaths = new ArrayList<>();

        System.out.println("============================================================================");
        System.out.println("Generating test case inputs for method: " + clsName + "." + mtdName + "()");
        System.out.println("============================================================================");

        switch (type) {
            case FLOW_ALL_DEF:
                innerPaths = getAllDefPaths();
                break;
            case FLOW_ALL_USE:
                innerPaths = getAllUsePaths();
                break;
            case FLOW_ALL_DEF_USE:
                innerPaths = getAllDUPaths();
                break;
            default:
                return new ArrayList<String>();
        }


        try {
            testSet = new ArrayList<String>();

            pathCount = innerPaths.size();

            System.out.println(innerPaths);

            for (List<Unit> innerPath : innerPaths) {
                List<List<Unit>> headToHerePaths = new ArrayList<>();
                List<List<Unit>> hereToTailPaths = new ArrayList<>();
                headToHerePaths = Findpath.getAllSimplePathBetween(ug.getHeads(),
                        innerPath.get(0), ug);
                hereToTailPaths = Findpath.getAllSimplePathBetween(innerPath.get(innerPath.size() - 1),
                        ug.getTails(), ug);
                List<Unit> tempPath = new ArrayList<>();
                boolean isPossible = false;
                Tuple tempTuple = new Tuple<String, String>("", "");

                findPath:
                for (List<Unit> headToHerePath : headToHerePaths) {
                    for (List<Unit> hereToTailPath : hereToTailPaths) {
//                        将du路径拼接为起点到终点的简单路径
                        tempPath = innerPath;
                        tempPath.addAll(0, headToHerePath.subList(0,headToHerePath.size()-1));
                        tempPath.addAll(hereToTailPath.subList(1,hereToTailPath.size()));

//                        System.out.println("The path is: " + path.toString());
                        tempTuple = calPathConstraintWithoutPrint(tempPath);
                        pathConstraint = (String) tempTuple.second;

//                        约束无解，路径不可能
                        if (!pathConstraint.isEmpty() && solve(pathConstraint).equals("")) {
                        } else {
                            if (pathConstraint.isEmpty()) {
                                String curTestCase=randomTC(body.getParameterLocals());
                                if(!testSet.contains(curTestCase)){
                                    testSet.add(curTestCase);
                                }

                            } else {
                                String curTestCase=solve(pathConstraint);
                                if(!testSet.contains(curTestCase)){
                                    testSet.add(curTestCase);
                                }
                            }
                            pathCoveredCount++;
                            isPossible = true;
                            break findPath;

                        }

                    }
                }
                if (isPossible) {
                    System.out.println("The path is: " + tempPath.toString());
                    System.out.println("\t" + tempTuple.first);
                    System.out.println("\tThe corresponding path constraint is: " + pathConstraint);
                } else {
                    impossiblePrimePaths.add(innerPath);
                }

            }

        } catch (Exception e) {
            System.err.println("Error in generating test cases: ");
            System.err.println(e.toString());
        }

        if (!testSet.isEmpty()) {
            System.out.println("");
            System.out.println("The generated test case inputs:");
            int count = 1;

            for (String tc : testSet) {
                System.out.println("( " + count + " ) " + tc.toString());
                count++;
            }
        }

        System.out.println("The coverage rate is " + pathCoveredCount + " / " + pathCount + " .");
        if (!impossiblePrimePaths.isEmpty()) {
            System.out.println("The impossible path are:");

            for (List<Unit> impossiblePrimePath : impossiblePrimePaths) {
                System.out.println("The path is: " + impossiblePrimePath);
            }
        }

        return testSet;
    }

    public Tuple<String, String> calPathConstraintWithoutPrint(List<Unit> path) {

        List<Local> jVars = getJVars();

        String pathConstraint = "";
        String expectedResult = "";

        HashMap<String, String> assignList = new HashMap<>();
        ArrayList<String> stepConditionsWithJimpleVars = new ArrayList<String>();
        ArrayList<String> stepConditions = new ArrayList<String>();

        String stringToPrint = "";

        for (Unit stmt : path) {

            if (stmt instanceof JAssignStmt) {
                assignList.put(((JAssignStmt) stmt).getLeftOp().toString(),
                        ((JAssignStmt) stmt).getRightOp().toString());
                continue;
            }
            if (stmt instanceof JIfStmt) {

                String ifstms = ((JIfStmt) stmt).getCondition().toString();
                int nextUnitIndex = path.indexOf(stmt) + 1;
                Unit nextUnit = path.get(nextUnitIndex);

                //如果ifstmt的后继语句不是ifstmt中goto语句，说明ifstmt中的条件为假
                if (!((JIfStmt) stmt).getTarget().equals(nextUnit)) {
                    ifstms = "!( " + ifstms + " )";
                } else {
                    ifstms = "( " + ifstms + " )";
                }
                stepConditionsWithJimpleVars.add(ifstms);
                continue;
            }
            if (stmt instanceof JReturnStmt) {
                expectedResult = stmt.toString().replace("return", "").trim();
            }
        }


        stringToPrint = "The step conditions with JimpleVars are: " + stepConditionsWithJimpleVars;

        //bug 没有考虑jVars为空的情况
        if (jVars.size() != 0) {
            for (String cond : stepConditionsWithJimpleVars) {
                //替换条件里的Jimple变量
                for (Local lv : jVars) {
                    if (cond.contains(lv.toString())) {
                        stepConditions.add(cond.replace(lv.toString(), assignList.get(lv.toString()).trim()));
                    }
                }
            }
        } else {
            stepConditions = stepConditionsWithJimpleVars;
        }

        if (stepConditions.isEmpty()) {
            return new Tuple<>(stringToPrint, "");
        }
        pathConstraint = stepConditions.get(0);
        int i = 1;
        while (i < stepConditions.size()) {
            pathConstraint = pathConstraint + " && " + stepConditions.get(i);
            i++;
        }
        //System.out.println("The path expression is: " + pathConstraint);
        return new Tuple<>(stringToPrint, pathConstraint);
    }

    public String solve(String pathConstraint) throws Exception {
        return Z3Solver.solve(pathConstraint);
    }

    public String randomTC(List<Local> parameters) {

        String varName;
        String varValue = "";
        String testinput = "";

        for (Local para : parameters) {
            varName = para.getName();
            if ("int".equals(para.getType().toString())) {
                varValue = String.valueOf((int) (Math.random() * 10));
            }
            if ("String".equals(para.getType().toString())) {
                varValue = "abc";
            }
            //其它的基本类型没写
            testinput = testinput + " " + varName + "=" + varValue;
        }
        return testinput;
    }

}
