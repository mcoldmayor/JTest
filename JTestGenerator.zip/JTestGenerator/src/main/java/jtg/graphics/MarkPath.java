package jtg.graphics;

import soot.Unit;

import java.util.ArrayList;
import java.util.List;

public class MarkPath implements Comparable<MarkPath>{
    public boolean isRepeatable=true;
    public List<Unit> path;
    public MarkPath() {
        this.path = new ArrayList<>();
    }
    public MarkPath(List<Unit> path) {
        this.path = new ArrayList<>(path);
    }
    public MarkPath(List<Unit> path, boolean isRepeatable) {
        this.path = new ArrayList<>(path);
        this.isRepeatable = isRepeatable;
    }
    public MarkPath(MarkPath mPath) {
        this.isRepeatable = mPath.isRepeatable;
        this.path = new ArrayList<>(mPath.path);
    }
    public boolean add(Unit e) {
        return path.add(e);
    }
    public Unit get(int index) {
        return path.get(index);
    }
    public boolean remove(Unit e) {
        return path.remove(e);
    }

    @Override
    public int compareTo(MarkPath o) {
        return o.path.size() - path.size();
    }
}
