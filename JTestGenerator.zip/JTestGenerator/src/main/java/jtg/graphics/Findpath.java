package jtg.graphics;

import soot.Unit;
import soot.toolkits.graph.UnitGraph;

import java.util.*;

public class Findpath {

    public static List<List<Unit>> getAllPrimePath(UnitGraph unitGraph) {
        List<MarkPath> raw= new ArrayList<>();
        List<List<Unit>> ret = new ArrayList<>();
        for(Unit u: unitGraph) {
            HashMap<Unit, Boolean> visited = new HashMap<>();
            List<Unit> curPath = new ArrayList<>();
            dfsForMarkSimplePath(unitGraph, u, curPath, visited, raw);
        }
        Collections.sort(raw);

        for (int i = 0; i < raw.size(); i++) {
            if (raw.get(i).isRepeatable) {
                boolean rep = false;
                for (int j = 0; j < i; j++) {
                    if (!raw.get(j).isRepeatable && isSub(raw.get(i).path, raw.get(j).path)) {
                        rep = true;
                    }
                }
                raw.get(i).isRepeatable = rep;
                if (!rep) {
                    ret.add(raw.get(i).path);
                }
            } else {
                ret.add(raw.get(i).path);
            }

        }
        return ret;
    }

    private static void dfsForMarkSimplePath(UnitGraph ug, Unit from, List<Unit> curPath,
                                             HashMap<Unit, Boolean> visited, List<MarkPath> ret) {
        visited.put(from, true);
        curPath.add(from);

        if (ug.getTails().contains(from)) {
            ret.add(new MarkPath(curPath, true));
            curPath.remove(curPath.size()-1);
            visited.put(from, false);
            return;
        }
        int branches = 0;
        for (Unit succ : ug.getSuccsOf(from)) {
            if (!visited.getOrDefault(succ, false)) {
                dfsForMarkSimplePath(ug, succ, curPath, visited, ret);
                branches ++;
            } else if (succ.equals(curPath.get(0))) {
                curPath.add(succ);
                ret.add(new MarkPath(curPath, false));
                curPath.remove(curPath.size()-1);
                branches ++;
            }
        }
        if (branches == 0) {
            ret.add(new MarkPath(curPath));
        }
        curPath.remove(curPath.size()-1);
        visited.put(from, false);
        return;
    }

    private static void dfsForSimplePath(UnitGraph ug, Unit from, List<Unit> curPath, HashMap<Unit, Boolean> visited, List<List<Unit>> ret) {
        curPath.add(from);
        visited.put(from, true);

        if (ug.getTails().contains(from) || from.equals(curPath.get(0))) {
            ret.add(new ArrayList<>(curPath));
            curPath.remove(from);
            visited.put(from, false);
            return;
        }
        int branches = 0;
        for (Unit succ : ug.getSuccsOf(from)) {
            if (!visited.getOrDefault(succ, false) || succ.equals(curPath.get(0))) {
                dfsForSimplePath(ug, succ, curPath, visited, ret);
                branches ++;
            }
        }
        if (branches == 0) {
            ret.add(new ArrayList<>(curPath));
        }
        curPath.remove(from);
        visited.put(from, false);
        return;
    }

    private static void dfsForSimplePath(UnitGraph ug, Unit from, Unit to, List<Unit> curPath, HashMap<Unit, Boolean> visited, List<List<Unit>> ret) {
        curPath.add(from);
        visited.put(from, true);

        if (from.equals(to)) {
            ret.add(new ArrayList<>(curPath));
            curPath.remove(curPath.size()-1);
            visited.put(from, false);
            return;
        }

        if (ug.getTails().contains(from) || (from.equals(curPath.get(0)) && curPath.size()>1)) {
            curPath.remove(curPath.size()-1);
            visited.put(from, false);
            return;
        }


        for (Unit succ : ug.getSuccsOf(from)) {
            if (!visited.getOrDefault(succ, false)) {
                dfsForSimplePath(ug, succ, to, curPath, visited, ret);
            }
        }
        curPath.remove(curPath.size()-1);
        visited.put(from, false);
    }

    private static boolean isSub(List<Unit> path1, List<Unit> path2) {
        if (path2.size() < path1.size()) {
            return false;
        }
        for (int i = 0; i < path2.size(); i++) {
            if (path2.get(i).equals(path1.get(0))) {
                boolean ret = true;
                for (int j = 0; j < path1.size(); j++) {
                    if (i + j >= path2.size()) {
                        ret = false;
                        break;
                    }
                    if (!path1.get(j).equals(path2.get(i + j))) {
                        ret = false;
                        break;
                    }
                }
                if (ret) {
                    return true;
                }
            }
        }
        return false;
    }

    public static List<List<Unit>> getAllSimplePathBetween(Unit from,Unit to,UnitGraph unitGraph){
        ArrayList<List<Unit>> ret = new ArrayList<>();
        ArrayList<Unit> cur = new ArrayList<>();
        HashMap<Unit, Boolean> visited = new HashMap<>();
        dfsForSimplePath(unitGraph, from, to, cur, visited, ret);
        return ret;
    }

    public static List<List<Unit>> getAllSimplePathBetween(List<Unit> froms,Unit to,UnitGraph unitGraph){
        List<List<Unit>> simplePaths=new ArrayList<>();
        for(Unit from : froms){
            simplePaths.addAll(getAllSimplePathBetween(from,to,unitGraph));
        }
        return simplePaths;
    }

    public static List<List<Unit>> getAllSimplePathBetween(Unit from,List<Unit> tos,UnitGraph unitGraph){
        List<List<Unit>> simplePaths=new ArrayList<>();
        for(Unit to : tos){
            simplePaths.addAll(getAllSimplePathBetween(from,to,unitGraph));
        }
        return simplePaths;
    }

    public static List<List<Unit>> getAllSimplePathBetween(List<Unit> froms,List<Unit> tos,UnitGraph unitGraph){
        List<List<Unit>> simplePaths=new ArrayList<>();
        for(Unit to : tos){
            for (Unit from : froms) {
                simplePaths.addAll(getAllSimplePathBetween(from, to, unitGraph));
            }
        }
        return simplePaths;
    }

}
